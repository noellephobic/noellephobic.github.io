(function($){
	"use strict";

	$(document).ready(function(){
		
		console.log('test', $('#learn-press-advertisement'));
		$('#learn-press-advertisement').remove();
	});
})(jQuery);